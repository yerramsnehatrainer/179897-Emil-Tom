package com.ust.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class FundTransfer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long transaction_Id;
	private long sender_accountno;
	private long recipient_accountno;
	private String dateof_transaction;
	private double transaction_amount;
	public long getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(long transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public long getSender_accountno() {
		return sender_accountno;
	}
	public void setSender_accountno(long sender_accountno) {
		this.sender_accountno = sender_accountno;
	}
	public long getRecipient_accountno() {
		return recipient_accountno;
	}
	public void setRecipient_accountno(long recipient_accountno) {
		this.recipient_accountno = recipient_accountno;
	}
	public String getDateof_transaction() {
		return dateof_transaction;
	}
	public void setDateof_transaction(String dateof_transaction) {
		this.dateof_transaction = dateof_transaction;
	}
	public double getTransaction_amount() {
		return transaction_amount;
	}
	public void setTransaction_amount(double transaction_amount) {
		this.transaction_amount = transaction_amount;
	}
	@Override
	public String toString() {
		return "FundTransfer [transaction_Id=" + transaction_Id + ", sender_accountno=" + sender_accountno
				+ ", recipient_accountno=" + recipient_accountno + ", dateof_transaction=" + dateof_transaction
				+ ", transaction_amount=" + transaction_amount + "]";
	}

	
	
	
	

}
